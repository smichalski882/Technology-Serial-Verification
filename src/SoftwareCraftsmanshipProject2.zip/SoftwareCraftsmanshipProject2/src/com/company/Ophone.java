package com.company;

import com.company.AbstractProduct;

import java.math.BigInteger;
import java.util.Optional;
import java.util.Set;

public final class Ophone extends AbstractProduct {

    //Fields
    private SerialNumber serialNumber;
    private Optional<Set<String>> description;

    //Constructor
    public Ophone(SerialNumber serialNumber, Optional<Set<String>> description){
        super(serialNumber, description);
    }

    //Methods
    public ProductType getProductType(){
        return ProductType.OPHONE;
    }

    @Override
    public String getProductName() {
        return ProductType.OPHONE.getName();
    }

    public static boolean isValidSerialNumber(SerialNumber serialNumber){
        return serialNumber.isOdd()&&serialNumber.gcd(new SerialNumber(BigInteger.valueOf(630))).compareTo(BigInteger.valueOf(32)) >= 0;
    }

    @Override
    public Optional<Set<String>> getDescription() {
        return Optional.empty();
    }
}
