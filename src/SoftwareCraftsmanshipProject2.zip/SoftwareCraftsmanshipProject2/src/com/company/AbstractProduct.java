package com.company;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public abstract class AbstractProduct implements Product {

    private SerialNumber serialNumber;
    private Optional<Set<String>> description;

    //product constructor needs serialnumber and a description
    public AbstractProduct(SerialNumber serialNumber, Optional<Set<String>> description){
        this.serialNumber = serialNumber;
        this.description = description;
    }

    @Override
    public SerialNumber getSerialNumber(){
        return this.serialNumber;
    }


    @Override
    public Optional<Set<String>> getDescription(){
        return this.description;
    }

    //two products are equal so long as their serial numbers are equal
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AbstractProduct that = (AbstractProduct) o;
        return Objects.equals(serialNumber, that.serialNumber);
    }

    //returns the same hash so long as the serial numbers are the same
    @Override
    public int hashCode() {
        return Objects.hash(serialNumber);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("The name of the product is " + this.getProductName() + ". ");
        builder.append("It's serial number is " + this.getSerialNumber() + ". ");
        this.getDescription().get().stream().forEach(e -> builder.append(e.substring(0, 1).toUpperCase() + e.substring(1)));
        return builder.toString();
    }
}
