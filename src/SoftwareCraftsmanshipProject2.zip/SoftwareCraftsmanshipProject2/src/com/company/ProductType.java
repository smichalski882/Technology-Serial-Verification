package com.company;

public enum ProductType{
    OPOD, OPAD, OPHONE, OWATCH, OTV;

    //field to store productName
    private String productName;

    //method to set the name
    public void setName(String string){
        this.productName = string;
    }

    //method to return the name of this enum
    public String getName(){
        String name = new String();
        switch(this){
            case OPOD:
                return "oPod";
            case OPAD:
                return "oPad";
            case OPHONE:
                return "oPhone";
            case OWATCH:
                return "oWatch";
            case OTV:
                return "oTv";
        }
        return null;
    }
}
