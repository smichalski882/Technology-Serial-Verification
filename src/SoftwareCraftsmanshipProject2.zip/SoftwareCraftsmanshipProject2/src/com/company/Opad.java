package com.company;

import com.company.AbstractProduct;

import java.util.Optional;
import java.util.Set;

public final class Opad extends AbstractProduct {

    //Fields
    private SerialNumber serialNumber;
    private Optional<Set<String>> description;

    //Constructor
    public Opad(SerialNumber serialNumber, Optional<Set<String>> description){
        super(serialNumber, description);
    }

    //Methods
    public ProductType getProductType(){
        return ProductType.OPAD;
    }

    @Override
    public String getProductName() {
        return ProductType.OPAD.getName();
    }

    public static boolean isValidSerialNumber(SerialNumber serialNumber){
        return serialNumber.isEven()&&serialNumber.testBit(3);
    }
}
