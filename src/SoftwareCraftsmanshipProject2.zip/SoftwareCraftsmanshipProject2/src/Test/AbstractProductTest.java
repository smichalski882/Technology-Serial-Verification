package Test;
import com.company.*;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.junit.gen5.api.Assertions.assertEquals;

public class AbstractProductTest {
    @Test
    void testEquals() {
        Set<String> opadSet = new HashSet<>();
        opadSet.add("for all your tablet utility needs.");
        opadSet.add("starting at the low low price of $15,000!!");
        Optional<Set<String>> description = Optional.of(opadSet);
        SerialNumber serialNumber = new SerialNumber(BigInteger.valueOf(24));
        Opad opad = new Opad(serialNumber, description);
        Opad opad2 = new Opad(serialNumber, description);
        assertEquals(true, opad.equals(opad2));
    }

    @Test
    void testHashCode() {
        Set<String> opadSet = new HashSet<>();
        opadSet.add("for all your tablet utility needs.");
        opadSet.add("starting at the low low price of $15,000!!");
        Optional<Set<String>> description = Optional.of(opadSet);
        SerialNumber serialNumber = new SerialNumber(BigInteger.valueOf(24));
        Opad opad = new Opad(serialNumber, description);
        Opad opad2 = new Opad(serialNumber, description);
        assertEquals(true, opad.hashCode() == opad2.hashCode());
    }

    @Test
    void testToString() {
        Set<String> opadSet = new HashSet<>();
        opadSet.add("for all your tablet utility needs.");
        opadSet.add("starting at the low low price of $15,000!!");
        Optional<Set<String>> description = Optional.of(opadSet);
        SerialNumber serialNumber = new SerialNumber(BigInteger.valueOf(24));
        Opad opad = new Opad(serialNumber, description);
        String string = "The name of the product is oPad. It's serial number is com.company.SerialNumber@401e7803. For all your tablet utility needs.Starting at the low low price of $15,000!!";
        System.out.println(opad.toString());
        assertEquals(true, opad.toString().equals(string));
    }
}
