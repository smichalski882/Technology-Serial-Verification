package Test;
import com.company.Ophone;
import com.company.Opod;
import com.company.ProductType;
import com.company.SerialNumber;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.junit.gen5.api.Assertions.assertEquals;

public class OphoneTest {

    @Test
    void testGetProduct(){
        Set<String> ophoneSet = new HashSet<>();
        ophoneSet.add("for all your cell phone calling needs. ");
        ophoneSet.add("starting at the low low price of $15,000!!");
        Optional<Set<String>> description = Optional.of(ophoneSet);
        SerialNumber serialNumber = new SerialNumber(BigInteger.valueOf(945));
        Ophone ophone = new Ophone(serialNumber, description);
        assertEquals(ProductType.OPHONE, ophone.getProductType());
    }

    @Test
    void testGetName(){
        Set<String> ophoneSet = new HashSet<>();
        ophoneSet.add("for all your cell phone calling needs. ");
        ophoneSet.add("starting at the low low price of $15,000!!");
        Optional<Set<String>> description = Optional.of(ophoneSet);
        SerialNumber serialNumber = new SerialNumber(BigInteger.valueOf(945));
        Ophone ophone = new Ophone(serialNumber, description);
        assertEquals("oPhone", ophone.getProductName());
    }

    @Test
    void testIsValidSerialNumber(){
        Set<String> ophoneSet = new HashSet<>();
        ophoneSet.add("for all your cell phone calling needs. ");
        ophoneSet.add("starting at the low low price of $15,000!!");
        Optional<Set<String>> description = Optional.of(ophoneSet);
        SerialNumber serialNumber = new SerialNumber(BigInteger.valueOf(945));
        Ophone ophone = new Ophone(serialNumber, description);
        assertEquals(true, ophone.isValidSerialNumber(ophone.getSerialNumber()));
    }

}
