package Test;
import com.company.*;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.junit.gen5.api.Assertions.assertEquals;

public class OpadTest {

    @Test
    void testGetProduct(){
        Set<String> opadSet = new HashSet<>();
        opadSet.add("for all your tablet utility needs. ");
        opadSet.add("starting at the low low price of $15,000!!");
        Optional<Set<String>> description = Optional.of(opadSet);
        SerialNumber serialNumber = new SerialNumber(BigInteger.valueOf(24));
        Opad opad = new Opad(serialNumber, description);
        assertEquals(ProductType.OPAD, opad.getProductType());
    }

    @Test
    void testGetName(){
        Set<String> opadSet = new HashSet<>();
        opadSet.add("for all your tablet utility needs. ");
        opadSet.add("starting at the low low price of $15,000!!");
        Optional<Set<String>> description = Optional.of(opadSet);
        SerialNumber serialNumber = new SerialNumber(BigInteger.valueOf(24));
        Opad opad = new Opad(serialNumber, description);
        assertEquals("oPad", opad.getProductName());
    }

    @Test
    void testIsValidSerialNumber(){
        Set<String> opadSet = new HashSet<>();
        opadSet.add("for all your tablet utility needs. ");
        opadSet.add("starting at the low low price of $15,000!!");
        Optional<Set<String>> description = Optional.of(opadSet);
        SerialNumber serialNumber = new SerialNumber(BigInteger.valueOf(24));
        Opad opad = new Opad(serialNumber, description);
        assertEquals(true, opad.isValidSerialNumber(opad.getSerialNumber()));
    }

}
